function X=SparseDiag(x)
X=sparse(diag(x(:)));
end

